# Ghost-worker-detection-system (BioGuard Prototype)

**What this is:** A working prototype (Flask + SQLite + simple heuristics) for detecting ghost workers,
duplicate identities and suspicious benefit claims. This package includes a simple web UI and
helper utilities so you can run the system locally for testing.

## What I added
- `utils/` package with:
  - `biometric_matcher.py` — face/image hashing and simple matching (graceful fallback if face_recognition isn't installed)
  - `fraud_detection.py` — heuristic detectors for ghost workers and suspicious claims
  - `data_generator.py` — sample data generator used by `/api/generate-sample-data`
- `run.sh` — small helper script to install requirements and run the app
- `requirements.txt` — (kept from upload)

## Quick start (Linux / macOS)
```bash
# create virtualenv (recommended)
python3 -m venv venv
source venv/bin/activate

# install dependencies and run
pip install -r requirements.txt
python app.py
```

The app will start on http://0.0.0.0:5000 . Open `index.html` or `http://localhost:5000/` in your browser.

## Notes
- The `utils/biometric_matcher.py` uses `face_recognition` if available. If not, it falls back to hashing the image bytes, which is deterministic but less robust than face encodings.
- Some uploaded files were `.pyc` compiled files — I rebuilt their source equivalents. If you have the original `.py` files, you can replace the `utils/` files.

## Next steps I can help with
- Add real face recognition pipeline and calibration
- Secure the API with authentication
- Deploy to a server or Docker

## Files included in this ZIP
See root of repo. Enjoy!
