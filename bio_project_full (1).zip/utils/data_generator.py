"""Simple data generator for sample employees, attendance logs and claims."""
import random, uuid
from datetime import datetime, timedelta

def generate_employee():
    names = ['John Doe','Jane Smith','Mary Johnson','Peter Brown','Alice Green','Bob Blue','Cathy White','David Black']
    name = random.choice(names) + ' ' + str(uuid.uuid4())[:6]
    digital_id = str(uuid.uuid4())
    reg_days_ago = random.randint(0,120)
    return {
        'digital_id': digital_id,
        'name': name,
        'national_id': str(random.randint(10000000,99999999)),
        'department': random.choice(['Finance','IT','HR','Operations']),
        'position': random.choice(['Officer','Manager','Clerk','Analyst']),
        'phone': '+2547' + str(random.randint(10000000,9999999)),
        'email': name.replace(' ','').lower() + '@example.com',
        'photo_path': None,
        'biometric_hash': None,
        'registration_date': datetime.utcnow() - timedelta(days=reg_days_ago),
        'status': 'active',
        'created_by': 'system'
    }

def generate_attendance_log(employee_id, start_date, count=10):
    logs = []
    for i in range(count):
        ts = start_date + timedelta(days=i)
        logs.append({
            'employee_id': employee_id,
            'check_in_time': ts,
            'verification_method': random.choice(['facial','fingerprint','id_card']),
            'confidence_score': random.uniform(70,100),
            'location': random.choice(['Main Office','Branch A','Branch B']),
            'device_id': 'SIM-' + str(random.randint(1000,9999))
        })
    return logs

def generate_benefit_claim(emp_id):
    return {
        'employee_id': emp_id,
        'benefit_type': random.choice(['Health','Transport','Housing']),
        'amount': round(random.uniform(50,2000),2),
        'claim_date': datetime.utcnow(),
        'status': 'pending',
        'verified_by_biometric': random.choice([True, False]),
        'notes': ''
    }
