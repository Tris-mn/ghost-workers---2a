"""Utilities package for Ghost-worker-detection-system"""
from .biometric_matcher import generate_biometric_hash, image_to_hash, detect_duplicate, verify_biometric
from .fraud_detection import detect_ghost_workers, detect_duplicate_claims, detect_unusual_patterns, analyze_employee_risk
from .data_generator import generate_employee, generate_attendance_log, generate_benefit_claim
