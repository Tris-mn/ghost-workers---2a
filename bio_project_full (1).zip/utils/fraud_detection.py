"""Basic fraud detection heuristics for the prototype."""
from datetime import datetime, timedelta
import random

def detect_ghost_workers(employees, attendance_logs, days_threshold=30):
    """Return list of potential ghost workers:
    Criteria: registered but no attendance within days_threshold OR very low attendance rate.
    """
    # Build last attendance map
    last_seen = {}
    for log in attendance_logs:
        emp_id = getattr(log, 'employee_id', None)
        ts = getattr(log, 'check_in_time', None)
        if emp_id:
            if emp_id not in last_seen or (ts and ts>last_seen[emp_id]):
                last_seen[emp_id] = ts
    ghosts = []
    now = datetime.utcnow()
    for emp in employees:
        last = last_seen.get(emp.id)
        days_since_att = (now - last).days if last else None
        days_since_reg = (now - emp.registration_date).days if getattr(emp, 'registration_date', None) else None
        reason = ''
        flag = False
        if days_since_att is None:
            reason = 'No attendance records'
            flag = True
        elif days_since_att and days_since_att>days_threshold:
            reason = f'Last attendance {days_since_att} days ago'
            flag = True
        if flag:
            ghosts.append({'employee': emp, 'reason': reason, 'days_since_registration': days_since_reg, 'days_since_attendance': days_since_att})
    # sort by days since attendance desc
    ghosts.sort(key=lambda x: (x.get('days_since_attendance') or 0), reverse=True)
    return ghosts

def detect_duplicate_claims(claims):
    """Group claims by employee and detect suspicious patterns (rapid multiple claims)."""
    suspicious = []
    from collections import defaultdict
    by_emp = defaultdict(list)
    for c in claims:
        by_emp[c.employee_id].append(c)
    for emp_id, items in by_emp.items():
        if len(items)>1:
            # check time differences
            items_sorted = sorted(items, key=lambda x: x.claim_date)
            pairs = []
            for i in range(len(items_sorted)-1):
                td = (items_sorted[i+1].claim_date - items_sorted[i].claim_date).total_seconds()/3600.0
                if td < 24.0:
                    pairs.append((items_sorted[i], items_sorted[i+1], td))
            if pairs:
                suspicious.append({'employee_id': emp_id, 'claims': items_sorted, 'time_difference_hours': [p[2] for p in pairs], 'reason':'Multiple claims within 24 hours'})
    return suspicious

def detect_unusual_patterns(attendance_logs):
    """Placeholder for time-series anomaly detection."""
    # Very simple: flag logs with confidence_score < 30
    return [log for log in attendance_logs if getattr(log,'confidence_score',100) < 30.0]

def analyze_employee_risk(employee, attendance_logs):
    """Return a risk score (0-100) for a given employee based on heuristics."""
    # base risk
    risk = 0.0
    now = datetime.utcnow()
    # no attendance -> high risk
    emp_logs = [l for l in attendance_logs if l.employee_id==employee.id]
    if len(emp_logs)==0:
        risk += 80.0
    else:
        # average confidence low increases risk
        avg_conf = sum([getattr(l,'confidence_score',100) for l in emp_logs])/len(emp_logs)
        if avg_conf < 60:
            risk += 30.0
    # randomness to diversify
    risk = min(100.0, risk + random.uniform(-5,5))
    return {'employee_id': employee.id, 'risk_score': round(risk,2)}
