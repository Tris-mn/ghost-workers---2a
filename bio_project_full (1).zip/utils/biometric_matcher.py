"""Simple biometric utilities with graceful fallbacks.

Functions:
- generate_biometric_hash(data): create a stable hash (for fingerprints or small templates)
- image_to_hash(base64_data_or_bytes): create a facial 'hash' / encoding from image.
- detect_duplicate(new_data, existing_data): compare hashes and return possible duplicates.
- verify_biometric(verification_data, template_data): verify provided biometric against stored template.
"""
import hashlib
import json
import base64
from io import BytesIO

try:
    from PIL import Image
except Exception:
    Image = None

try:
    import face_recognition
except Exception:
    face_recognition = None

def generate_biometric_hash(data: str) -> str:
    """Generate a SHA256 hash from arbitrary biometric data (string)."""
    if isinstance(data, str):
        raw = data.encode('utf-8')
    else:
        raw = data
    return hashlib.sha256(raw).hexdigest()

def _pillow_image_from_base64(b64str):
    if ',' in b64str:
        b64str = b64str.split(',', 1)[1]
    img_bytes = base64.b64decode(b64str)
    if Image:
        return Image.open(BytesIO(img_bytes)).convert('RGB')
    else:
        return img_bytes

def image_to_hash(image_input):
    """Attempt to produce a facial encoding-like hash from an image.
    Accepts either a base64 data URL string or raw bytes.
    If face_recognition is available, returns a JSON string with real encoding.
    Otherwise returns a hashed fingerprint of image bytes.
    """
    try:
        # If face_recognition is installed, use it to extract encodings
        if face_recognition:
            if isinstance(image_input, str):
                if ',' in image_input:
                    image_input = image_input.split(',',1)[1]
                img_bytes = base64.b64decode(image_input)
                import numpy as np
                from PIL import Image as PILImage
                arr = face_recognition.api.load_image_file(BytesIO(img_bytes))
            else:
                arr = image_input
            encs = face_recognition.face_encodings(arr)
            if encs:
                enc = encs[0].tolist()
                return json.dumps({'type':'face_encoding','encoding':enc})
        # Fallback: hash the image bytes (deterministic)
        if isinstance(image_input, str):
            if ',' in image_input:
                image_input = image_input.split(',',1)[1]
            img_bytes = base64.b64decode(image_input)
        else:
            img_bytes = image_input if isinstance(image_input, (bytes, bytearray)) else str(image_input).encode('utf-8')
        h = hashlib.sha256(img_bytes).hexdigest()
        return json.dumps({'type':'image_hash','hash':h})
    except Exception as e:
        # Last-resort: hash repr
        return json.dumps({'type':'error_hash','hash':hashlib.sha256(str(e).encode()).hexdigest()})

def _similarity_score_hash(h1, h2):
    """Naive similarity between two hex hashes (number of matching hex chars)."""
    if not h1 or not h2:
        return 0.0
    # Compare as strings
    matches = sum(1 for a,b in zip(h1, h2) if a==b)
    return (matches / max(len(h1), len(h2))) * 100.0

def detect_duplicate(new_data, existing_data):
    """Compare new_data against a list of existing_data; return list of possible duplicates.
    new_data: {'name','national_id','biometric_hash','photo_data'}
    existing_data: list of {'id','name','national_id','biometric_hash','photo_data'}
    Returns list of dicts: {'employee':..., 'similarity_score':float, 'matching_factors':[...]}.
    """
    results = []
    new_hash = None
    try:
        if new_data.get('biometric_hash'):
            # stored as JSON string possibly
            j = new_data['biometric_hash']
            if isinstance(j, dict):
                new_hash = j.get('hash') or j.get('encoding')
            else:
                try:
                    parsed = json.loads(j)
                    new_hash = parsed.get('hash') or parsed.get('encoding')
                except Exception:
                    new_hash = j
    except Exception:
        new_hash = None

    for emp in existing_data:
        score = 0.0
        factors = []
        # national id exact match gives high score
        if new_data.get('national_id') and emp.get('national_id') and new_data['national_id']==emp['national_id']:
            score += 90.0
            factors.append('national_id')
        # name fuzzy: exact match adds moderate score
        if new_data.get('name') and emp.get('name') and new_data['name'].strip().lower()==emp['name'].strip().lower():
            score += 30.0
            factors.append('name')
        # compare image/hash
        emp_hash = None
        if emp.get('biometric_hash'):
            try:
                parsed = json.loads(emp['biometric_hash'])
                emp_hash = parsed.get('hash') or parsed.get('encoding')
            except Exception:
                emp_hash = emp['biometric_hash']
        if new_hash and emp_hash:
            # if they're lists (face encoding), compute distance
            try:
                if isinstance(new_hash, list) and isinstance(emp_hash, list):
                    # simple euclidean distance -> convert to similarity
                    import math
                    dist = math.sqrt(sum((a-b)**2 for a,b in zip(new_hash, emp_hash)))
                    sim = max(0.0, 100.0 - (dist*10))  # heuristic
                    score += sim * 0.5
                    factors.append('face_encoding')
                else:
                    sim = _similarity_score_hash(str(new_hash), str(emp_hash))
                    score += sim * 0.4
                    factors.append('image_hash')
            except Exception:
                pass
        if score>0:
            results.append({'employee':emp,'similarity_score':round(min(score,100.0),2),'matching_factors':factors})
    # sort desc
    results.sort(key=lambda x: x['similarity_score'], reverse=True)
    return results

def verify_biometric(verification_data, template_data):
    """Verify verification_data against template_data. Both may be JSON strings or dicts.
    Returns {'match':bool,'confidence':float}
    """
    try:
        if isinstance(template_data, str):
            template_data = json.loads(template_data)
    except Exception:
        pass
    try:
        if isinstance(verification_data, str):
            try:
                verification_data = json.loads(verification_data)
            except Exception:
                # verification_data may be base64 image string
                verification_data = {'image': verification_data}
    except Exception:
        verification_data = {'raw': str(verification_data)}

    # If template contains face encoding and verification provides image, try matching
    t = template_data
    if t.get('type')=='face_encoding' and verification_data.get('image'):
        # if face_recognition available, do proper compare
        if face_recognition:
            if isinstance(verification_data['image'], str):
                img_b64 = verification_data['image']
                if ',' in img_b64:
                    img_b64 = img_b64.split(',',1)[1]
                img_bytes = base64.b64decode(img_b64)
                import numpy as np
                arr = face_recognition.api.load_image_file(BytesIO(img_bytes))
            else:
                arr = verification_data['image']
            encs = face_recognition.face_encodings(arr)
            if encs:
                import numpy as np, math
                d = face_recognition.face_distance([t['encoding']], encs[0])
                confidence = max(0.0, 100.0 - float(d[0])*100.0)
                return {'match': confidence>75.0, 'confidence': round(confidence,2)}
        # fallback: hash compare
    # fallback compare hashes
    vhash = None
    if verification_data.get('hash'):
        vhash = verification_data['hash']
    elif verification_data.get('image'):
        try:
            # compute image hash
            if isinstance(verification_data['image'], str):
                if ',' in verification_data['image']:
                    b = verification_data['image'].split(',',1)[1]
                    vhash = hashlib.sha256(base64.b64decode(b)).hexdigest()
                else:
                    vhash = hashlib.sha256(verification_data['image'].encode()).hexdigest()
            else:
                vhash = hashlib.sha256(verification_data['image']).hexdigest()
        except Exception:
            vhash = None
    thash = None
    if t.get('hash'):
        thash = t.get('hash')
    elif t.get('encoding'):
        thash = None
    if vhash and thash:
        sim = _similarity_score_hash(str(vhash), str(thash))
        return {'match': sim>80.0, 'confidence': round(sim,2)}
    # default: no match with low confidence
    return {'match': False, 'confidence': 0.0}
